﻿namespace ApiCrud;

// CHAVE KEY DO TOKEN
public class Configuration
{
    public static string PrivateKey { get; set; } = "w@#8Lg!v1Zq$2Mx*N&pRtAeyK/nA1B2C3D4E";
}