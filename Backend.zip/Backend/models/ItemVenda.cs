﻿namespace ApiCrud.models;

// MAPEANDO AS ENTIDADES 
public class ItemVenda
{
    public Produto Produto { get; set; }
    public int Quantidade { get; set; }
    
}